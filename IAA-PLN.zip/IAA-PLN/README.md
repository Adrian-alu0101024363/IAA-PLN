# IAA-PLN
# symspellpy para checkear spelling
Negative aciertos: 6524 Positive aciertos: 11853
Aciertos: 18377 Precision: 0.55